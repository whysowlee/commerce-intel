# 29CM 어댑터

조사 시점 **2026-07-29**, 브랜드 목록 경로 추가 **2026-07-30**.
"확인"은 그날 실제 응답으로 검증한 것, "미검증"은 확인하지 못한 것이다.
**미검증 항목을 사실처럼 쓰지 마라.**

29CM는 스토리 A의 플랫폼 비교 상대다. **기본은 경로 A(API)다** (2026-07-30 재개정,
SPEC v16) — 카테고리·검색은 PLP API(§2-2, `totalCount` 제공), 브랜드는 BEST API 합집합(§3),
랭킹은 BEST API(§2-1). 브라우저(경로 B)는 백업이다.
**단 브랜드 카탈로그는 BEST API가 전량이 아님이 실측됐다**(435 중 422, §0) —
**화면 총계와 대조하고 어긋나면 브라우저 순회로 보완한다.** 스킴이 바뀌면(400/404·
필드 소실) 경로 B로 폴백해 완주하고 보고한 뒤 이 문서를 개정한다.

## 접근 정책

`robots.txt` 확인: `User-agent: *` → `Allow: /`. 차단은 `/my-page/`, `/order/`, `/auth/` 등
로그인 영역뿐이다. Baiduspider만 전면 차단. 403·봇 차단·캡차 없이 전 페이지 200이었다.

## §0. 목록은 서버 HTML엔 없고 브라우저엔 있다 (2026-07-30 정정)

**구 표는 서버 HTML 기준이었다.** "없다"로 적혀 있던 목록들이 브라우저로 열면 전부 렌더된다.

| 페이지 | 서버 HTML | **브라우저 렌더 후** |
|---|---|---|
| **상품 상세** `/products/{itemId}` | **있다** — JSON-LD와 페이로드에 전체 데이터 | 있다 |
| 카테고리 목록 | 없다 — 이름·breadcrumb만 | **완전 렌더** — 50개/페이지, 7,567개 완주 |
| 브랜드 목록 | 없다 — 단 `__NEXT_DATA__`에 브랜드 메타는 있다 (§3) | **완전 렌더** — 435개 완주 |
| 검색 결과 | 없다 | 미측정 |

### 브라우저 순회 (경로 B — 백업·총계 대조·전량 보완용)

폴백으로 내려갔거나, 화면 총계를 읽거나, 브랜드 카탈로그의 BEST API 누락분을 보완할 때 쓴다.
**무한 스크롤이 아니라 `&page=` 페이지네이션이다.** URL에 `page=1`이 자동으로 붙는다.

| 항목 | 실측 (2026-07-30) |
|---|---|
| 페이지 크기 | **50개/페이지**, 페이지 간 겹침 0건 |
| 카드 선택자 | **DOM으로 잡는다** — `/catalog/` 고유 id가 **1개**이고 가격 텍스트가 있는 가장 가까운 조상. 실측 카드는 `div.mb-40.space-y-12`이고 그 안에 `/catalog/` 링크가 4개 있다 |
| 상품 URL | `/catalog/{itemId}` (`/products/`가 아니다) |
| 종료 판정 | 빈 페이지 + `"선택한 필터의 검색 결과가 없습니다."` — **결정적** |
| 완주 검증 | 남성 데님팬츠 151×50 + 17 = **7,567 = 화면 총계 일치** |
| | 인사일런스 브랜드 8×50 + 35 = **435 = 화면 총계 일치** |

**화면이 총계를 노출한다** (`7,567개`, `435개`). 이게 완전성 검증의 근거다 — 경로 A는
총계를 주지 않는다(§3).

카드 원문:
```
브랜드 | 상품명 | 37% | 57,960 | 쿠폰 | 조건부 무료배송 | 단독 | 2.8천 | 4.5 (53)
                할인율  판매가                                좋아요  평점 (후기수)
```

- **함정: 가격에 `원`이 없다.** `원`을 기준으로 카드 컨테이너를 찾으면 `li`를 지나쳐
  `ul`까지 올라가고 **카드 텍스트가 이웃 카드로 번진다**(실측에서 발생).
  가격은 `\d{2,3},\d{3}` 같은 숫자 패턴으로 찾아라
- **함정: HTML 문자열에 `<li>` 정규식을 쓰면 카드를 놓친다** (2026-07-30 실측).
  `<li[^>]*>(?:(?!</li>).)*?</li>` 로 자르면 **574/608(94%)만 잡힌다** — 카드 안에
  색상 옵션이 중첩 `<li>`로 들어 있어서 정규식이 첫 `</li>`에서 끊긴다.
  **DOM으로 잡으면 608/608**이다(13페이지 50·50·…·8, 빈 페이지로 종료).
  카드 = **고유 `/catalog/` id가 1개**이고 가격 텍스트가 있는 가장 가까운 조상.
  링크 수로 세면 안 된다 — 카드마다 `/catalog/` 링크가 4개다
- 좋아요는 **축약 표기**(`2.8천`)다 — **정수로 파싱해 `like_count`에 담고**
  원문은 `like_count_display`에 남긴다 (SPEC v15). 목록 API(§2-1·§2-2)를 쓰면
  `likeCount`가 애초에 정수라 이 문제가 없다
- **품절 상품이 기본으로 포함된다** — 필터 이름이 `품절상품 제외`이고 기본은 꺼져 있다
  (인사일런스 435건 중 품절 131건). **무신사는 반대로 기본이 품절 제외다**(563 vs 2,022) —
  **플랫폼을 비교할 때 필터를 맞춰라.** 안 맞추면 결론이 뒤집힌다: 실측에서
  무신사(품절 제외) vs 29CM(품절 포함)으로 비교하니 "29CM 단독 입점 83건"이 나왔는데,
  무신사를 품절 포함으로 맞추자 90건이 무신사 품절 상품과 매칭돼 **0건**이 됐다
- `보는 중`/`구매 중` 같은 실시간 지표는 29CM에 없다

### 경로 A(BEST API)는 전량이 아니다 — 품절이 빠진다 (2026-07-30 실측)

BEST API는 facet으로 카테고리와 **브랜드**를 모두 받아 빠르고 파싱이 안정적이다:

| 무엇을 받나 | facet | 검증 |
|---|---|---|
| 소분류 카테고리 전체 | `categoryFacetInputs` | 여성 데님 팬츠 2,580개 완주 (2026-07-29) |
| **브랜드 전 상품** | **`brandFacetInputs`** | 인사일런스 **422개** / 5페이지 (2026-07-30) |

**하지만 이 API는 카탈로그 전량을 주지 않는다.**

| | 건수 |
|---|---|
| 브라우저 순회 = 화면 총계 | **435** |
| 경로 A (정렬 4종 합집합, `hasNext=false` 도달) | **422** |
| 누락 | **13건 (3.0%)** — 이 중 **11건이 품절** |
| 유령(수집엔 있고 화면엔 없음) | 0건 — 수집분 ⊂ 화면집합 |

**누락 원인은 특정하지 못했다.** 처음에 "랭킹이라 품절을 뺀다"고 적었으나 틀렸다 —
**같은 수집분에 품절이 이미 120건 있다.** 저조한 반응 때문도 아니다: 누락 13건은
좋아요 4~39·후기 0~3인데 수집분에는 좋아요 5 이하가 35건, 후기 0건이 172건 있다.
**누락된 상품을 구별해 주는 관측 가능한 기준이 없다.**

확립된 사실은 두 개다.

- **경로 A는 전량이 아니다** — 435 중 422. 수집분 ⊂ 화면집합, 유령 0건
- **누락이 품절 쪽으로 치우친다** — 누락분 품절률 **85%**(11/13) vs 수집분 **28%**(120/422).
  약 3배 편향이지만 필터가 아니다

**어떤 상품이 빠질지 예측할 수 없다는 것이 규칙을 만든다 — 화면 총계 대조 없이는
전량을 주장하지 마라.**

**그래서 경로별 역할이 이렇게 갈린다 (2026-07-30 재개정 — 경로 A 우선):**

| 목적 | 경로 |
|---|---|
| **카테고리 전수·검색**(스토리 B) | **PLP API(§2-2)** — `totalCount`를 주므로 검증이 A 안에서 완결. 브라우저 불필요 |
| **브랜드 카탈로그 전량**(스토리 A) | **BEST API `MONTHLY` 정렬 합집합(§3)** → **화면 총계와 대조** → 어긋나면(누락 실측 13건) **브라우저 순회로 보완** |
| 랭킹(스토리 C) | BEST API(§2-1) — 랭킹 자체가 목적이라 카탈로그 전량이 기준이 아니다 |
| 폴백·화면 총계·화면 전용 값 | 브라우저 순회(경로 B, §0) |

전체 순회 검증은 데님팬츠와 인사일런스에서만 했으니 다른 대상에선 화면 총계와
대조하며 진행해라.

### 함정 — 페이지를 마크다운으로 변환해 읽으면 데이터가 사라진다

상품 상세를 마크다운 변환기로 읽으면 "빈 SPA 껍데기, 지표 없음"처럼 보인다.
**하지만 실제 HTML에는 296KB짜리 JSON-LD와 페이로드가 들어 있다.**
변환기가 `<script>` 안의 데이터를 버리기 때문이다.

**"데이터가 없다"고 판단하기 전에 원본 HTML을 확인해라.** 반대로 목록 페이지의
"상품 없음"은 원본 HTML로도 확인된 진짜 사실이다.

## 1. URL 패턴 (확인)

| 대상 | URL |
|---|---|
| 상품 상세 | `https://www.29cm.co.kr/products/{itemId}` |
| 브랜드 | `https://www.29cm.co.kr/store/brand/{brandId}?brandId={brandId}&sort=RECOMMENDED` |
| 카테고리 | `https://www.29cm.co.kr/store/category/list?categoryLargeCode={대}&categoryMediumCode={중}&categorySmallCode={소}&sort=RECOMMENDED&defaultSort=RECOMMENDED` |

구형 URL은 리다이렉트된다: `product.29cm.co.kr/catalog/{id}` → 307,
`shop.29cm.co.kr/brand/{id}` → 302. 새 형식을 쓴다.

**`sort`와 `defaultSort`를 빼면 카테고리 페이지의 breadcrumb·메타가 아예 렌더되지 않는다.**
코드로 카테고리 이름을 확인하려면 반드시 붙여라.

## 2. 카테고리 코드 (확인)

**9자리, 3단계**(대/중/소)이고 하위 코드는 상위 코드의 접두사를 공유한다.
카테고리 페이지의 `meta[name=description]`이 서버 렌더되므로 코드→이름 확인이 된다.

```
268100100 여성의류            272100100 남성의류
  268106100 바지                272104100 하의
    268106101 스트레이트          272104101 스트레이트 팬츠
    268106102 와이드             272104102 와이드 팬츠
    268106104 데님              272104104 데님 팬츠      ← 스토리 B 대상
    268106106 슬랙스            272104106 슬랙스
286100100 레저                290100100 키즈
```

남성 데님 팬츠 정규 URL (확인):
```
https://www.29cm.co.kr/store/category/list?categoryLargeCode=272100100&categoryMediumCode=272104100&categorySmallCode=272104104&sort=RECOMMENDED&defaultSort=RECOMMENDED
```

위에 없는 카테고리 코드는 **미검증**이다. 사이트 네비게이션에서 직접 읽어라
(전체 트리는 `data/.tools/ranking_targets.json`에 실측 카탈로그로 있다 — 29CM 1,399개).

**성별 축은 대분류로 갈린다** — 여성의류(268)/남성의류(272)가 따로다. 무신사의 `gf`처럼
같은 카테고리를 성별로 자르는 파라미터가 아니다. 그래서 **소분류 구성도 성별마다 다르다**:

- 여성의류>바지(268106100) 소분류 10종 — 쇼트·슬림·스트레이트·와이드·데님·트레이닝·
  레깅스·슬랙스·부츠컷·기타 팬츠. **'코튼 팬츠'가 없다**
- 남성의류>하의(272104100)에는 **코튼 팬츠(272104105, 2,878개)가 있다**

**한쪽 성별에만 있는 카테고리를 반대 성별로 요청받으면** 없는 것을 있는 것처럼 만들지 말고
스킬 §B의 "사이트에 없는 상품군" 절차(검색 ∩ 상위 카테고리)를 따른다. 여성 바지에는
소재 필터도 없다(`facet-group.attributeFacets: []`) — 그래서 검색이 유일한 경로다.

## 2-1. BEST 랭킹 — 목록을 주는 유일한 확인된 JSON 경로 (확인, 2026-07-29)

UI(`/best-products`)는 중분류('바지')까지만 고를 수 있지만, **뒤의 API는 소분류 필터를
받는다.** 비로그인 200 확인.

```
POST https://display-bff-api.29cm.co.kr/api/v1/plp/best/items
Content-Type: application/json

{"pageRequest": {"page": 1, "size": 100},
 "userSegment": {"gender": "ALL|M|F", "age": "ALL|TEENAGER|TWENTIES|THIRTIES|FORTIES|FIFTIES"},
 "facets": {
   "categoryFacetInputs": [{"largeId": 268100100, "middleId": 268106100, "smallId": 268106104}],
   "periodFacetInput": {"type": "HOURLY|DAILY|WEEKLY|MONTHLY", "order": "DESC"},
   "rankingFacetInput": {"type": "POPULARITY|ORDER|LIKE"}}}
```

- 소분류 `268106104`(여성 데님 팬츠)로 100건 + `hasNext` 확인 — 전부 데님 상품
- **소분류 랭킹은 독립 랭킹이다** (2026-07-29 대조 검증). "바지 랭킹에서 데님만
  거른 것"이 아니다 — 같은 조건으로 두 목록을 받아 대조한 결과 데님 top 100의 84개가
  바지 top 100에 없었고(바지 top 100 안의 데님은 4개뿐), 순서도 불일치했다.
  소분류끼리 따로 랭킹이 매겨진다
- **소분류 랭킹은 카테고리 전체까지 이어진다** — 여성 데님 팬츠 기준 26페이지,
  총 2,580개에서 `hasNext=false` 확인. **top 100은 1페이지 요청 1번이면 끝난다.**
  같은 이유로 이 API는 스토리 B(전수조사)의 29CM 목록 수집 경로로도 쓸 수 있다
  (랭킹순 정렬일 뿐 전체 카테고리 목록이다 — 검증은 데님팬츠에서만 했다)
- 랭킹 종류 전체 어휘(400 응답이 노출, 확인): `POPULARITY` 인기순 / `ORDER` 구매순 /
  `CLICK` / `LIKE` 좋아요순 / `CART`.
  기간 전체 어휘: `HOURLY`(실시간) / `DAILY` / `WEEKLY` / `MONTHLY` / `MONTHS_3` / `MONTHS_6`
- **과거 소급 조회는 불가능하다** (2026-07-29 서버 측 검증). 이 API는 실존 필드의 잘못된
  값에는 400+허용값 목록을 주는데, `baseDate`/`targetDate` 등 날짜형 후보 17개를 일부러
  잘못된 타입으로 보내도 전부 200 — **필드 자체가 없다.** 기간은 전부 트레일링 윈도우이고
  기준일 지정 수단이 서버에 존재하지 않는다. 축적만이 방법이다
- `order`는 `ASC`를 보내도 `DESC`와 동일 응답(무시로 보임, 사유 미검증)
- 응답 `data.list[].itemInfo`: `productName`, `brandName`(+`brandId`), `originalPrice`,
  `displayPrice`(판매가), `saleRate`, `likeCount`, `reviewCount`,
  **`reviewScore`(0~5 그대로 — 무신사와 달리 변환 불필요)**, `isSoldOut`, `thumbnailUrl`.
  상품 URL은 `https://product.29cm.co.kr/catalog/{itemId}` (307로 신형 URL로 넘어간다)
- 무신사 랭킹의 `viewers_now`/`buyers_now` 같은 실시간 지표는 **응답에 없다**
- 카테고리 트리: `GET https://recommend-api.29cm.co.kr/api/v4/best/categories?categoryList=<코드,..>`

### 스토리 C 확정 기준 (2026-07-29 사용자 컨펌)

- **기본 기준: `HOURLY`(실시간) + `POPULARITY`(인기순) + `gender=ALL, age=ALL`.**
  사용자가 기간이나 성별을 따로 말하지 않으면 이 조합으로 수집한다.
  한 스냅샷은 한 번의 요청으로 만들고, 여러 번 요청해 섞지 마라
- **축적 주기는 1시간이다** (2026-07-29 결정) — `HOURLY`라는 이름 그대로 1시간 갱신으로
  본다(갱신 시각 필드·공식 안내 없음). 더 촘촘히 찍으면 같은 랭킹을 중복 저장할 뿐이다.
  응답 순서는 결정적이다(12초 내 연속 4회 top-100 완전 일치 실측) — **순서가 바뀌면
  진짜 갱신이다**
- **폴백**: 이 API가 막히면 소분류 랭킹은 다른 경로가 없다(화면은 중분류까지만).
  **중분류('바지') 랭킹으로 낮춰 수집**하되 ① 대체 사실을 리포트와 `meta.notes`에
  명시하고 ② `meta.target`을 중분류 이름으로 저장하며 ③ **기존 소분류 스냅샷과는
  diff하지 않는다** — 다른 랭킹이라 비교가 성립하지 않는다.
  (`diff_snapshots.py`는 `target`이 다르면 자동으로 걸러낸다 — 그래서 target을
  낮춘 이름으로 정직하게 저장하는 것이 중요하다)

**함정 두 가지:**
1. 필드명이 페이지 URL 파라미터와 **다르다** — `period`가 아니라 `periodFacetInput.type`,
   카테고리는 `largeId`/`middleId`/`smallId`. **틀린 필드명을 보내면 400이 아니라
   200 + 빈 목록이 온다.** 빈 목록이 나오면 "상품 없음"이 아니라 요청 형식부터 의심해라.
2. 경로 B(화면)로는 소분류 랭킹을 볼 수 없다 — 위 폴백 규칙을 따른다.

## 2-2. 목록 PLP API — 스토리 B의 주 경로 (확인, 2026-07-30)

**화면(경로 B)이 실제로 쓰는 목록 API다.** 랭킹인 BEST API(§2-1)와 달리 **총계를 준다**
— 그래서 완전성 검증이 API 안에서 끝난다. 비로그인 curl 200 확인.

```
POST https://display-bff-api.29cm.co.kr/api/v1/listing/items         # 목록 (50개/페이지)
POST https://display-bff-api.29cm.co.kr/api/v1/listing/items/count   # 총계만
POST https://display-bff-api.29cm.co.kr/api/v1/listing/facet-group   # 좁힐 축 + 축별 개수
Content-Type: application/json

{"pageType": "CATEGORY_PLP",              // 검색이면 "SRP" + "keyword": "코튼 팬츠"
 "sortType": "RECOMMENDED",
 "facets": {"categoryFacetInputs": [{"largeId": 268100100, "middleId": 268106100}],
            "priceFacetInput": {"min": 100000, "max": 200000}},
 "pageRequest": {"page": 1, "size": 50}}
```

- 응답 `data.pagination`: `{page, size, hasNext, totalCount}` — **`totalCount`가 화면
  총계와 같다**(여성 바지 64,891 vs 화면 `64,882개`, 몇 분 사이의 시점차). `source_total`은 이 값이다
- 응답 `data.list[]`: `itemId` · `itemInfo`(BEST API와 같은 필드 이름 — `productName`,
  `originalPrice`, `displayPrice`, `sellPrice`, `saleRate`, `reviewScore`, `reviewCount`,
  `likeCount`, `isSoldOut`, `thumbnailUrl`) · **`itemEvent.eventProperties`**
- **카테고리 이름이 목록에 직접 온다** — `eventProperties.largeCategoryName` /
  `middleCategoryName` / `smallCategoryName`. §필드 매핑의 "코드 → meta description 해석"이
  **이 경로에서는 필요 없다.** `isAd`도 여기 있다
- **품절 포함이 기본이다**(§0과 같다). `stockFacet`으로 개수가 확인된다 —
  여성 바지 `IN_STOCK 56,863 / SOLD_OUT 8,019`
- 종료 판정은 `hasNext=false` + 빈 페이지 두 가지 다 있다
- `size`는 50(화면 기본)과 100 모두 동작한다

#### ⚠️ 추천순으로 전수 순회하면 19%를 조용히 놓친다 (2026-07-30 실측)

`sortType: "RECOMMENDED"`(화면 기본값)는 **깊은 페이지에서 순서가 흔들린다.**
페이지를 한 장씩 넘기는 동안 목록이 재배열되어 **경계 상품이 중복으로 오고 그만큼 건너뛴다.**

| 정렬 | 200~230페이지 중복률 | 300~330페이지 |
|---|---|---|
| `RECOMMENDED` | **13.9%** | 9.8% |
| `NEWEST` · `LOWEST_PRICE` · `MOST_LIKED` | **0.0%** | — |

여성 바지 ∩ 검색 `코튼 팬츠`(총계 17,093)를 추천순으로 342페이지 완주했더니
**유니크 13,811건(19% 누락)**이었다. 페이지네이션 자체는 정상이다 — 342페이지까지 이어지고
마지막 페이지가 43건에서 `hasNext=false`로 끝난다. **누락은 정렬 때문이다.**

- **전수 순회는 결정적 정렬로 한다** — `NEWEST`가 기본이다(`LOWEST_PRICE`·`MOST_LIKED`도 0%)
- 같은 페이지를 두 번 요청하면 추천순도 동일하게 온다(50/50 일치) — **재현 테스트로는
  안 잡힌다.** 깊이가 쌓여야 드러나므로 **총계 대조가 유일한 탐지 수단이다**
- 유효한 `sortType` 어휘(`/api/v1/listing/sorts?pageType=SRP` 응답):
  `RECOMMENDED` `NEWEST` `MOST_REVIEWED` `LOWEST_PRICE` `HIGHEST_PRICE`
  `HIGHEST_DISCOUNT` `MOST_LIKED` `MOST_SOLD`

### `facet-group` — 범위 협의를 한 번의 요청으로 끝낸다

스토리 B의 "좁힐 축의 **실제 개수**를 조회해서 제시하라"가 이 호출 하나로 된다.
같은 body(`pageRequest` 없이)를 보내면:

| 키 | 내용 |
|---|---|
| `categoryFacet.values[]` | 교차 카테고리까지 포함한 **소분류별 count** (예: 여성 바지 — 와이드 19,644 / 쇼트 15,178 / 데님 13,321 / 기타 팬츠 9,846 / 트레이닝 8,975 / 슬랙스 5,116 / 스트레이트 4,357 / 부츠컷 4,002 / 레깅스 2,119 / 슬림 579) |
| `priceFacet` | `{min, max}` — 그 범위의 최저·최고가 |
| `stockFacet` `discountFacet` `deliveryFacet` `promotionFacet` `tagFacet` | 타입별 count |
| `brandFacet.values[]` | 브랜드별 count (`frontBrandNo` 포함 — §3의 facet 입력값과 같은 ID) |
| `colorFacet.values[]` | 색상별 count |
| `attributeFacets` | **소재·핏 같은 속성 필터. 카테고리에 따라 빈 배열이다** — 여성 바지는 `[]`였다 |
| `totalCount` | 범위 총계 |

- **가격 필터는 `priceFacetInput: {min, max}`다** (실측: 여성 바지 10~20만원 23,317).
  **`priceFacetInputs: [{minPrice, maxPrice}]`처럼 틀리게 보내면 400이 아니라
  200 + 총계가 그대로 온다** — §2-1의 함정과 같은 성질이다. 필터를 걸었으면
  **총계가 실제로 줄었는지 대조해라**

### 검색(SRP) — 사이트에 없는 상품군을 잡는 경로

같은 API에 `pageType: "SRP"` + `keyword`를 준다. 카테고리 facet과 **함께** 보내면
교집합이 된다(스킬 §B의 "사이트에 없는 상품군" 절차가 이걸 쓴다).

- **검색은 소재·상세까지 훑는 넓은 유사매칭이다.** 여성 바지 안에서
  `코튼 팬츠` 17,093 = `코튼팬츠` 17,093 ≈ `코튼` 17,137 ≈ **`면 팬츠` 17,163**
  (동의어 확장). 상품명에 실제로 코튼/cotton/면이 있는 비율은 **표본 350건에서 22.6%**였다
- **엉터리 키워드는 0으로 떨어진다** (2026-07-30 실측, 여성 바지 교집합):
  `우주` `티타늄 팬츠` `라면 팬츠` `코튼팬쯔`(오타) `가나다라마` `asdfqwerzxcv` `ㅁㄴㅇㄹ`
  `고양이` **전부 0건**. 반대로 `실크 팬츠`는 61건으로 정상 동작한다
- **토큰 변별력을 API로 잴 수 있다** — 여성 바지에서 `바지` 100.0% · `팬츠` 98.3% ·
  `와이드` 42.2% · `코튼` 26.4% · `데님` 22.3% · `린넨` 1.6%.
  카테고리 이름 불용어 목록을 손으로 관리할 필요가 없다(스킬 §B 가드 참조)
- 카테고리 없이 검색만 하면 범위가 확 넓어진다 — `코튼 팬츠` 전체 검색은 27,252건이고
  1위가 남성 코튼 팬츠 8,553건이다. **교집합 없이 쓰지 마라**

## 3. 브랜드 전 상품 수집 (확인, 2026-07-30)

**스토리 A의 주 경로다.** BEST API(§2-1)에 브랜드 facet이 있다.

```
POST https://display-bff-api.29cm.co.kr/api/v1/plp/best/items
Content-Type: application/json

{"pageRequest": {"page": 1, "size": 100},
 "userSegment": {"gender": "ALL", "age": "ALL"},
 "facets": {
   "brandFacetInputs": [{"frontBrandNo": 1642}],
   "periodFacetInput": {"type": "MONTHLY", "order": "DESC"},
   "rankingFacetInput": {"type": "POPULARITY"}}}
```

- **`frontBrandNo`가 필수 하위 필드다.** `brandId`나 `id`로 보내면
  `필수 필드 'facets.brandFacetInputs.?.frontBrandNo'이(가) 누락되었습니다`로 400이 온다
- **`frontBrandNo`는 `/store/brand/{brandId}` URL의 ID와 같은 값이다** (1642 → 인사일런스,
  응답의 `brandId`/`brandName`으로 교차 확인)
- 인사일런스 실측: **5페이지 / 422건 수신 / 유니크 421개**, `hasNext=false` 도달.
  `size=100` 동작 확인

### 함정 — 이 API는 랭킹이다. 창을 좁게 잡으면 카탈로그가 잘린다 (실측, 2026-07-30)

`periodFacetInput.type`은 **랭킹 집계 창**이고, 브랜드 전 상품 목록이 아니다.
인사일런스 유니크 상품 수를 창·정렬별로 다 세어봤다:

| 조합 | 유니크 | 합집합에서 빠진 것 |
|---|---|---|
| `MONTHLY` + `CLICK` | **422** | **0** |
| `MONTHLY` + `POPULARITY` | 421 | 1 |
| `MONTHLY` + `ORDER` | 420 | 2 |
| `MONTHLY` + `LIKE` | 412 | 10 |
| `DAILY` + `POPULARITY` | 409 | 13 |
| `WEEKLY` + `POPULARITY` | **365** | **57** |
| `HOURLY` + `POPULARITY` | **26** | — |
| `MONTHS_3` / `MONTHS_6` | **HTTP 500** | — |

**전 조합 합집합은 422개다.** `MONTHLY`는 거기에 1~2개 차이로 붙는다.
**그러나 422는 카탈로그 상한이 아니다 — 실제 카탈로그는 435개다**(브라우저 대조,
아래 "총계" 절). 합집합이 422에서 멈추는 것은 전량에 도달했다는 뜻이 아니라
**모든 정렬이 같은 품절 필터를 공유한다는 뜻**이었다.
하지만 `WEEKLY`로 잡으면 **57개(13%)가 조용히 빠지고**,
`HOURLY`는 26개뿐이다 — 스토리 C의 기본값(`HOURLY`)을 스토리 A에 그대로 쓰면 카탈로그가
94% 사라진다.

**스토리 A 규칙**: `MONTHLY`로 **정렬 종류를 훑어 합집합**을 만든다
(`POPULARITY` ∪ `CLICK` ∪ `ORDER` ∪ `LIKE`). 정렬당 5페이지 남짓이라 전부 합쳐도 수 초다.
한 조합만 쓰면 몇 개가 빠지는데, **빠진 상품은 "무신사 단독 입점"으로 잘못 집계된다** —
스토리1의 단독 입점 분석이 이 누락에 직접 오염되므로 합집합을 쓴다.

**`MONTHS_3`·`MONTHS_6`은 500을 낸다** (문서상 유효 어휘인데 서버가 죽는다). 쓰지 마라.

### 브랜드 카탈로그 총계 — 경로 A엔 없고 화면엔 있다 (2026-07-30 정정)

경로 A에는 총계가 없다. 브랜드 페이지 `__NEXT_DATA__`의 브랜드 메타에는 `likeCount`는
있어도 **상품 수가 없고**, 목록 API `pagination`에도 총계가 없다.

그래서 한동안 완전성 근거를 ① `hasNext=false` 도달 ② 정렬 조합 간 합집합이 더 이상
늘지 않음, 두 개로 삼았다. **이 두 근거는 완전성을 보장하지 않는다.**

**둘을 모두 만족한 422건이 실제로는 435건 중 422건이었다** (누락 13건, 품절 11건).
합집합 포화는 "전량 도달"이 아니라 "정렬들이 같은 필터를 공유"라는 뜻일 뿐이다.

**정정된 규칙:**

- **완전성 근거는 화면 총계 대조 하나뿐이다.** 브랜드 페이지를 브라우저로 열면
  **`435개`가 화면에 찍힌다** (§0). **경로 A 합집합으로 모은 뒤 이 총계와 대조하고,
  어긋나면 브라우저 순회로 보완해라** — 대조 없이 전량을 주장하지 않는다
- **`source_total`에는 화면에 노출된 총계를 담는다.** 순회 합집합 크기(=수집 건수)를
  넣으면 검증기가 자기 자신과 비교해 **오차가 항상 0.0%로 통과**한다.
  실제로 422/435를 "총계 대비 오차 0.0% — 기준 통과"로 보고한 사고가 있었다
- 화면 총계를 읽지 못했으면 `source_total`은 `null`로 두고 **검증을 건너뛴 사실을
  `meta.notes`에 남긴다.** 수집 건수로 채우지 않는다
- 경로 A로만 모았으면 `meta.notes`에 **"품절 상품이 빠졌을 수 있다"**를 남긴다

### 브랜드 ID 찾기 (확인, 2026-07-30)

두 방법 다 검증됐다.

1. **브랜드 페이지의 `__NEXT_DATA__`** — 상품 목록은 없지만 브랜드 메타는 서버 렌더된다.
   `https://www.29cm.co.kr/store/brand/{brandId}?brandId={brandId}&sort=RECOMMENDED`를 받아
   `<script id="__NEXT_DATA__">`를 파싱하면
   `{"brandId":1642,"nameKor":"인사일런스","nameEng":"INSILENCE", ...}`가 나온다.
   **ID를 알고 있을 때 그게 맞는 브랜드인지 확증하는 용도다**
2. **상품 상세의 JSON-LD `brand.url`** — 그 브랜드 상품 하나를 알고 있을 때 ID를 얻는 용도

`brandId=1642` = 인사일런스는 **1번 방법으로 확증됐다** (구 문서의 "추정" 표기 폐기).
모르는 브랜드는 검색으로 상품 하나를 찾아 2번으로 ID를 얻고, 1번으로 되짚어 확인해라.

## 4. 상품 상세에서 나오는 값 (확인)

상품 `3937672`, `2280520` 두 건 교차 확인.

| 지표 | 필드 | 나오나 |
|---|---|---|
| 좋아요(하트) | `heartCount` | 나온다 (9,918 / 2,783) |
| 후기 수 | `reviewAggregation.totalCount` | 나온다 |
| 평점 | `reviewAggregation.averagePoint` | 나온다 — **0~5 스케일** |
| 포토후기 수 | `totalPhotoReviewCount` | 나온다 |
| 정가 | `consumerPrice` | 나온다 |
| 판매가 | `sellPrice` | 나온다 |
| 할인율 | `discountRate` | 나온다 |
| 쿠폰적용가 | `totalDiscountedItemPrice` / `totalDiscountedRate` | 나온다 |
| 품절 | `isSoldOut`, `lastSoldOutAt` | 필드 있음 (품절 상품 실물은 미확보) |
| **조회수** | — | **안 나온다.** 페이로드 전체에 `view`/`hit`/`pv` 계열 필드가 하나도 없다 |
| **누적 판매량** | `soldQty` | **사실상 안 나온다** — `isDisplaySellQty: false`로 꺼져 있다 |

`soldQty`는 판매자 설정에 따라 켜질 수 있다. **`isDisplaySellQty`가 `true`일 때만
`purchase_count`에 담고, `false`면 `null`이다.** 꺼진 값을 읽어 담지 마라.

JSON-LD로도 같은 값을 얻을 수 있다: `offers.price`(판매가),
`offers.priceSpecification`(정가), `aggregateRating.ratingValue`/`reviewCount`,
`offers.availability`, `brand.url`.

**판매가는 쿠폰적용가(`totalDiscountedItemPrice`)다** (2026-07-30 개정).
무신사와 같은 개념으로 본다 — 비로그인 화면에 뜨는 전 회원 공통 쿠폰가이므로
개인화 가격이 아니라 누구나 받는 할인가다. `sellPrice`를 담으면 할인을 과소 기록한다.

> **⚠️ 단 `totalDiscountedItemPrice`는 화면 메인 판매가가 아니다** (2026-07-30 브라우저 실측).
> 그 값은 **「나의 구매 가능 가격 / 첫 구매가」**이고 **앱전용·Newbie(신규) 쿠폰이 얹힌다.**
> BEST top100 중 `displayPrice != sellPrice` 58건에서 **32건(55%)이 `displayPrice`와 다르다.**
> 결정적 사례 `2558259` — 한 화면에 두 가격이 따로 찍힌다: 메인 **5% 94,050**(`displayPrice`,
> 상품쿠폰) vs 나의 구매 가능 가격 **15% 84,150**(앱전용 15% 쿠폰).
> **판매가는 목록 경로(`displayPrice`)에서 담는 것이 안전하다.** 상세로 담아야 하면
> 화면 메인 가격과 대조해라 — 필드 이름만 보고 담으면 개인화 가격이 계약에 들어간다.

> **근거 수준 (2026-07-30 브라우저 실측으로 갱신)**: 무신사는 상세의 안내 문구("모든 회원이
> 사용 가능한 상품 쿠폰 중 최대 할인 쿠폰을 기준으로 산정")로 **확인**했다.
> **29CM에는 그런 문구가 아예 없다** — 비로그인 4개 상품에서 `모든 회원`·`전 회원`·`누구나`·
> `기준으로 산정` 0건이고 가격 영역 툴팁도 없다(`aria-label`·`title` 전수 확인).
> 대신 **동작으로 확인했다**: ① 화면 판매가가 `displayPrice`와 **4/4 일치**
> ② 가격을 정하는 상품쿠폰 43건이 **전부 무조건부**(첫구매·등급·신규·앱전용 0건)이고
> 43/43 `maxIssueCount: 0`(선착순 총량 없음, 7건만 1인 N매 캡)
> ③ 쿠폰이 여럿이면 **최대 할인 쿠폰이 자동 선택**된다 — 무신사가 문구로 밝힌 규칙과 같은
> 동작이고 29CM은 적지 않을 뿐이다.
> **문구 근거는 없고 동작 근거는 있다** — 그래서 미검증 표기를 뗀다.
> 참고: 「쿠폰받기」를 누르면 `"로그인이 필요해요."`가 뜬다. 거기서 멈춘다.

## 5. 리뷰 (확인)

> **스토리 B는 리뷰 본문을 수집하지 않는다(2026-07-29 결정).** 만족/불만족 판단은
> 노출된 후기 수·평균 평점만 쓴다. 아래는 검증된 사실의 기록으로 남긴다.

```
GET https://review-api.29cm.co.kr/api/v4/reviews?itemId={id}&page=0&size=50
```

비로그인 200. 지켜야 할 것:

1. **페이지가 0부터 시작한다.** `page=0`이 최신이다. 무신사(1부터)와 다르다.
2. `size`는 50, 100까지 동작을 확인했다. 범위를 넘기면 빈 배열이 온다 → 그걸로 끝을 판정한다.
3. **정렬 파라미터는 없다.** `sort=LATEST` / `HELPFUL` 모두 실패한다. 기본은 최신순이다.

부가 엔드포인트: `/api/v4/reviews/count`, `/api/v4/reviews/photo`, `/api/v4/review-bundle`

리뷰 필드(확인): `itemReviewNo`, `point`(1~5), `contents`, `insertTimestamp`(`YYYY-MM-DD HH:MM:SS`),
`optionValue`(예: `["[COLOR:SIZE]IVORY:S_01"]`), `userSize`, `helpfulCount`,
`surveyList`(예: `[{surveyType:"SIZE", optionValue:2}]`), `uploadFiles`, `isBlind`, `isGift`.

`isBlind`가 참인 리뷰는 제외한다. `userId`는 마스킹돼 오지만 **리포트에 옮기지 마라.**

## 필드 매핑

출처가 두 개다 — **목록 API(BEST)**와 **상품 상세(JSON-LD/페이로드)**. 필드명이 다르다.
스토리 A·B는 목록 API만으로 계약을 다 채울 수 있어 **상세를 열 필요가 없다.**

| 계약 | 목록 API (`data.list[].itemInfo`) | 상품 상세 |
|---|---|---|
| `product_id` | `itemId` (형제 노드) | `itemId` |
| `name` | `productName` | JSON-LD `name` |
| `url` | `https://www.29cm.co.kr/products/{itemId}` | 〃 |
| `image_url` | `thumbnailUrl` | JSON-LD `image` |
| `brand` | `brandName` | JSON-LD `brand.name` |
| `category` | `extraInfo.categories[]`의 코드 → **트리 API로 이름 해석** (아래) | JSON-LD `category` |
| `price_original` | `originalPrice` | `consumerPrice` |
| `price_sale` | **`displayPrice`**(쿠폰적용가) — 아래 함정 | `totalDiscountedItemPrice` ⚠️ **개인화 가격이 섞인다** — 앱전용·신규 쿠폰이 얹힌 「나의 구매 가능 가격」이고 58건 중 32건이 `displayPrice`와 다르다(§4). 목록 경로를 쓰는 편이 안전하다 |
| `discount_rate` | **`saleRate`**(쿠폰가 기준) — 아래 함정 | `totalDiscountedRate` |
| `review_count` | `reviewCount` | `reviewAggregation.totalCount` |
| `rating` | `reviewScore` (0~5 그대로) | `reviewAggregation.averagePoint` (0~5) |
| `like_count` | `likeCount` | `heartCount` |
| `view_count` | `null` — 29CM는 조회수를 노출하지 않는다 | `null` |
| `purchase_count` | `null` (목록에 없다) | `isDisplaySellQty`가 참일 때만 `soldQty` |
| `sold_out` | `isSoldOut` | `isSoldOut` |
| `viewers_now` `buyers_now` | `null` — 29CM에는 실시간 지표가 없다 | `null` |

### 함정 — 가격이 세 개다 (실측, 2026-07-30)

```
originalPrice 54,000   정가            ← price_original
sellPrice     43,200   쿠폰 전 판매가
displayPrice  37,160   쿠폰적용가       ← price_sale (2026-07-30 개정)
saleRate      31.0     displayPrice 기준 ← discount_rate
```

**세 값이 다 다르므로 어느 것을 담는지 반드시 의식해라.** 로우클래식 100개 실측에서
`displayPrice != sellPrice`인 상품이 **22개**였다(예: `3880226` 정가 79,000 ·
sell 79,000 · display 67,940 · saleRate 14 — 정가와 판매가가 같고 **쿠폰만 걸린** 경우다.
`sellPrice`를 담으면 이 상품은 "할인 없음"이 된다).

`saleRate`는 `displayPrice` 기준이라 `price_sale`을 `displayPrice`로 담으면 **짝이 맞는다.**
`sellPrice`를 담을 때만 `round((originalPrice - sellPrice) / originalPrice * 100)`으로
다시 계산해야 했다 — 이제 그럴 필요가 없다.

### 카테고리 코드 → 이름

목록 API는 `extraInfo.categories[]`에 **코드만** 준다:

```json
"extraInfo": {"categories": [{"largeCategoryCode": 272100100,
                              "mediumCategoryCode": 272103100,
                              "smallCategoryCode": 272103101}]}
```

**이름 해석은 카테고리 페이지의 `meta[name=description]`으로 한다** (2026-07-30 개정).

```
GET https://www.29cm.co.kr/store/category/list
    ?categoryLargeCode={앞3자리}100100&categoryMediumCode={앞6자리}100
    &categorySmallCode={코드}&sort=RECOMMENDED&defaultSort=RECOMMENDED
→ <meta name="description" content="29CM의 반소매 티셔츠(여성의류) 셀렉션을 만나보세요. …">
```

정규식 `29CM의 ([^(]+)\(` 로 이름을 뽑는다. 코드 앞 3자리가 대분류, 앞 6자리가 중분류다.
로우클래식 실측: **코드 93종 전부 해석 성공**(93/93), 상품 607/608에 채워졌다.

> **함정 — 트리 API는 쓰지 못한다.** `recommend-api.29cm.co.kr/api/v4/best/categories?categoryList=…`는
> 200을 주지만 응답이 `{"result":"SUCCESS","data":[]}`로 **비어 있다**(2026-07-30 실측,
> `268103101`·`268106104`로 확인). 게다가 응답이 **배열이 아니라 `data`로 감싼 객체**라
> 배열로 순회하면 문자열 키를 돌게 되어 `'str' object has no attribute 'get'`으로 죽는다.
> 구 문서의 배열 예시는 틀렸다.

**`smallCategoryCode`가 `null`인 상품이 있다** — 그때는 `mediumCategoryCode`의 이름으로
폴백한다. 둘 다 없으면 `category`는 결측이고, 결측률 5% 기준에 걸리니 건수를 확인해라.


## 무신사와 다른 점 정리

| | 무신사 | 29CM |
|---|---|---|
| 조회수 | **구간 표기로 노출** (`300회 이상 (최근 1개월)`) | 미노출 (필드 자체 없음) |
| 좋아요 | **노출** (상품 하트) | **노출** (`heartCount`) |
| 누적 판매 | 랭킹 배지에서만 | 기본 꺼짐 (`isDisplaySellQty`) |
| 실시간 "보는 중/구매 중" | **있다**(랭킹 목록) | 없다 |
| 목록 수집 | JSON으로 가능 | **JSON으로 가능** (BEST API — 2026-07-30) |
| 목록의 총 개수 | 응답에 있다 | **PLP API(§2-2)에는 있다**(`pagination.totalCount`). BEST API(§2-1)에는 `hasNext`만 |
| 목록 중복 | 없음 | **있다** — 422건 중 유니크 421 (dedup 필수) |
| 카테고리 이름 | 목록에 이름으로 온다 | **코드만** — 트리 API로 해석 |
| 리뷰 페이지 | 1부터, `pageSize`≤20 | **0부터**, `size` 50~100 |
| 평점 스케일 | 목록 0~100 / 상세 0~5 | 0~5 |

리포트의 "플랫폼별 인기"는 이 차이 때문에 **사이트마다 그릴 수 있는 차트가 다르다.**
EDA 결측 지도가 **어느 축이 쓸 수 있는지 먼저 판정하고**(결측 30% 초과면 그 축은
분석에서 빠진다), 분석 단은 남은 축으로만 검정한다. 없는 지표를 채우려 하지 마라 —
미노출은 `null`이고 그 사실이 리포트에 그대로 나온다.

### 스토리 A 멀티 플랫폼에서 주의할 것

두 사이트를 합집합으로 비교할 때(SPEC §4 스토리1) **비교 가능한 지표는 하트·후기·평점·
가격뿐이다.** 조회수와 누적판매는 29CM이 노출하지 않으므로 플랫폼 비교 차트를 만들지
않는다 — 무신사 쪽만 단독으로 그린다.

**상품명이 매칭 키다.** 목록 API의 `productName`을 그대로 담아라. 임의로 정리하거나
공백을 손보면 매칭이 어긋난다 — 정규화는 리포트 생성기가 한다.

## 런타임에 직접 확인할 것

2026-07-30에 1·2·6번이 해소됐다 — BEST API의 `brandFacetInputs`가 브랜드·카테고리 목록을
모두 페이지 번호 방식으로 주고(§3), 브랜드 ID는 `__NEXT_DATA__`로 확증된다.

남은 것:

1. **브랜드 규모 상한** — 인사일런스(422개, 5페이지)만 완주했다. 수천 개 브랜드에서
   `hasNext` 체인이 끝까지 가는지, 200페이지 안전 상한에 닿는지 확인
2. **합집합 422가 정말 카탈로그 전량인가** — 정렬 조합을 다 훑어도 422에서 멈추는 것은
   확인했지만, **사이트가 총계를 노출하지 않으므로 외부 기준과 대조하지 못했다.**
   브라우저로 브랜드 페이지를 끝까지 스크롤해 카드 수를 세면 대조가 된다(경로 B).
   차이가 나면 `MONTHLY` 창 밖의 상품이 있다는 뜻이다
3. 목록 중복의 원인 — 랭킹 순위 흔들림으로 추정하나 미확증. 다른 브랜드에서도 나는지
4. `MONTHS_3`·`MONTHS_6`의 500이 일시적인지 항구적인지
4. 정렬 드롭다운의 실제 유효값 (`RECOMMENDED`만 확인)
5. 품절 상품의 표시 방식과 `availability` 값 변화
